# SMPY

A Pen created on CodePen.

Original URL: [https://codepen.io/j3-fy/pen/bNNroGq](https://codepen.io/j3-fy/pen/bNNroGq).

